Little Lemon Restaurant - Capstone Project

Django REST API for menu and table booking system.

API Paths to test:
  - /api/menu/
  - /api/bookings/
  - /api/registration/

Test users:
  - Register new users at /api/registration/
  - Use token authentication with JWT or SessionAuth (configured in settings)

Database:
  - MySQL (set DB info in settings.py)

How to run:
  python manage.py makemigrations
  python manage.py migrate
  python manage.py runserver
