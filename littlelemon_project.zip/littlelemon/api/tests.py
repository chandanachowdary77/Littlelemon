from django.test import TestCase
from .models import Menu, Booking
from django.contrib.auth.models import User

class MenuModelTest(TestCase):
    def test_menu_creation(self):
        item = Menu.objects.create(name="Pizza", description="Cheese Pizza", price=9.99)
        self.assertEqual(str(item), "Pizza")

class BookingModelTest(TestCase):
    def test_booking_creation(self):
        user = User.objects.create_user(username="testuser", password="12345")
        booking = Booking.objects.create(user=user, date="2025-06-22", time="19:00", number_of_guests=2)
        self.assertEqual(str(booking), f"{user.username} - 2025-06-22")
